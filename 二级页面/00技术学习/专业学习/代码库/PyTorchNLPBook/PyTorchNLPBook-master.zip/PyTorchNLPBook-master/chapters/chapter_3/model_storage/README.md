# Model Storage

The notebooks are set to save to this directory.  Each notebook subdir has a symbolic link to here.